﻿using System;

Library BookFromLibrary = new Library();
BookFromLibrary.Read();

interface IBook
{
    void Read();
}


class UncleTomsCabin : IBook
{
    public void Read()
    {
        Console.WriteLine("You took: Uncle Tom's Cabin");
    }
}

class FlowersforAlgernon : IBook
{
    public void Read()
    {
        Console.WriteLine("You took: Flowers for Algernon");
    }
}


class Library : IBook
{
    private IBook UncleTomsCabin;
    private IBook FlowersforAlgernon;

    public Library()
    {
        UncleTomsCabin = new UncleTomsCabin();
        FlowersforAlgernon = new FlowersforAlgernon();
    }

    public void Read()
    {
        try
        {
            UncleTomsCabin.Read();
        }
        catch (Exception ex)
        {
            FlowersforAlgernon.Read();
        }
    }
}